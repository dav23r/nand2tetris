#!/bin/bash

./JackAnalyzer.py ../ArrayTest
./JackAnalyzer.py ../Square
./JackAnalyzer.py ../ExpressionLessSquare

